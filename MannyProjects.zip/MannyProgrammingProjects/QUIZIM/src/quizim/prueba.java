/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quizim_;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author damia
 */
public class prueba {
    
    
    
//    public static void lerr(){
//        FileReader entrada = null;
//        try {
//
//            
//            DefaultTableModel table = new DefaultTableModel();
//
//            entrada = new FileReader("C:\\FICHERO\\puntajes2.txt");  //LE ASINAMOS LA RUTA A NUESTRO OBJETO ENTRADA
//            BufferedReader leer = new BufferedReader(entrada);          //CREAMOS UN BUFFER PARA LEER EL ARCHIVO 
//
//            String lectura = "";          // CREAMOS LA VARIABLE LECTURA DE TIPO STRING
//
//            while (lectura != null) {       // UTILIZAMOS LA CONDICION WHILE Y LE DECIMOS QUE MIENTRAS rLECTURA SEA DIFERENTE DE NULL
//                lectura = leer.readLine(); // ENTONCES LECTURA MOSTRARA LINEA POR LINEA LO QUE CONTENGA EL ARCHIVO
//                //String cad2 = null;
//                String[] cad = lectura.split("/");
//                Scanner delimitar = new Scanner(Linea_archivo);//Se crea un scaner que lee lo que obtiene linea_archivo
//                delimitar.useDelimiter("/");
//                //cad2 = cad + "\n";
//                if (lectura != null) {
//                    // System.out.println(lectura);  // MOSTRAR EN CONSOLA EL CONTENIDO DEL FICHERO
//                    // table.addRow(cad);
//                    System.out.println( lectura);
//                  //System.out.println(cad[0] + "        " + cad[1] + "      " + cad[2] + "      " + cad[3]);
//                  
//                    //String imp = cad[0] + "        " + cad[1] + "      " + cad[2] + "      " + cad[3];
//                   // System.out.println( imp);
//                }
//
//            }
//
//        } catch (FileNotFoundException e) {  // CACHAMOS LA EXCEPCION DEL TIPO N SEGUN SEA EL CASO 
//            e.printStackTrace();         // LA MOSTRAMOS SI HAY UNA EXCEPCION EN EL COMPILAMINETO DEL PROGRAMA EN LA CONSOLA
//        } catch (IOException e) {      // CACHAMOS LA EXCEPCION DEL TIPO N SEGUN SEA EL CASO 
//            e.printStackTrace();   // LA MOSTRAMOS SI HAY UNA EXCEPCION EN EL COMPILAMINETO DEL PROGRAMA EN LA CONSOLA
//        } finally {                 // FINALIZAMOS LAS EXCEPCIONES DEL TIPO ENTRADA DE LECTURA
//
//        }
//        try {
//            entrada.close();     // CERRAMOS EL FIHCERO
//        } catch (IOException e) {   //CACHAMOS LA EXCEPCION 
//            e.printStackTrace();  // LA MOSTRAMOS SI HAY UNA EXCEPCION EN EL COMPILAMINETO DEL PROGRAMA EN LA CONSOLA
//        }
//    }

    public static void main(String args[]) {
        
      //  lerr();
    }

}
